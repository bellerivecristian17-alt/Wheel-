Navaeh PS5 Wheel Android app

This project wraps the black-and-blue YES/NO wheel in an Android app.
The result is programmed to always say YES.

BUILD AN APK USING ONLY YOUR ANDROID TABLET (CLOUD BUILD)

1. In your browser, sign in or create a GitHub account at https://github.com.
2. Create a NEW PUBLIC repository named NavaehPS5Wheel. Do not add a README or other files.
3. Extract this ZIP using your tablet's Files app.
4. Open the new repository on GitHub. Choose Add file > Upload files.
5. Upload the CONTENTS of the NavaehPS5Wheel folder, including the hidden .github/workflows/build-apk.yml file. If your file picker hides .github or cannot upload folders, use a file manager/editor that shows hidden files, or upload the files through GitHub's web editor. Keep the folder paths exactly as they are.
6. Commit the upload to the main branch.
7. Open the repository's Actions tab. Choose “Build Navaeh PS5 Wheel APK” if prompted, then select Run workflow. If it starts automatically after the commit, open that run instead.
8. Wait for the run to finish with a green check mark. Open the completed run and download the artifact named NavaehPS5Wheel-debug-apk.
9. Extract the downloaded artifact ZIP. It contains app-debug.apk. Tap the APK to install it. Android may ask you to allow your browser or Files app to install unknown apps; only enable this for the app you trust, then turn it off again afterward.

NOTES
- GitHub Actions builds the APK in the cloud; no computer or Android Studio is needed.
- This is a debug APK for personal testing, not a Play Store release.
- A public repository makes the source code visible to anyone. Do not put passwords or personal information in it.
- If the workflow fails, open the failed run and read the error in the Build debug APK step.
